import express, { Request, Response } from 'express';
import { z } from 'zod';
import { IStorage } from './storage.js';
import {
  insertTenantSchema,
  insertClusterSchema,
  insertApplicationSchema,
  insertServiceSchema,
  insertDeploymentSchema,
} from '../shared/schema.js';

export function createRouter(storage: IStorage) {
  const router = express.Router();

  // Tenant routes
  router.get('/api/tenants', async (req: Request, res: Response) => {
    try {
      const tenants = await storage.getTenants();
      res.json(tenants);
    } catch (error) {
      console.error('Error fetching tenants:', error);
      res.status(500).json({ error: 'Failed to fetch tenants' });
    }
  });

  router.get('/api/tenants/:id', async (req: Request, res: Response) => {
    try {
      const tenant = await storage.getTenant(req.params.id);
      if (!tenant) {
        return res.status(404).json({ error: 'Tenant not found' });
      }
      res.json(tenant);
    } catch (error) {
      console.error('Error fetching tenant:', error);
      res.status(500).json({ error: 'Failed to fetch tenant' });
    }
  });

  router.post('/api/tenants', async (req: Request, res: Response) => {
    try {
      const validatedData = insertTenantSchema.parse(req.body);
      const tenant = await storage.createTenant(validatedData);
      res.status(201).json(tenant);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid data', details: error.errors });
      }
      console.error('Error creating tenant:', error);
      res.status(500).json({ error: 'Failed to create tenant' });
    }
  });

  // Cluster routes
  router.get('/api/clusters', async (req: Request, res: Response) => {
    try {
      const tenantId = req.query.tenantId as string;
      const clusters = await storage.getClusters(tenantId);
      res.json(clusters);
    } catch (error) {
      console.error('Error fetching clusters:', error);
      res.status(500).json({ error: 'Failed to fetch clusters' });
    }
  });

  router.post('/api/clusters', async (req: Request, res: Response) => {
    try {
      const validatedData = insertClusterSchema.parse(req.body);
      const cluster = await storage.createCluster(validatedData);
      res.status(201).json(cluster);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid data', details: error.errors });
      }
      console.error('Error creating cluster:', error);
      res.status(500).json({ error: 'Failed to create cluster' });
    }
  });

  // Application routes
  router.get('/api/applications', async (req: Request, res: Response) => {
    try {
      const clusterId = req.query.clusterId as string;
      const applications = await storage.getApplications(clusterId);
      res.json(applications);
    } catch (error) {
      console.error('Error fetching applications:', error);
      res.status(500).json({ error: 'Failed to fetch applications' });
    }
  });

  router.post('/api/applications', async (req: Request, res: Response) => {
    try {
      const validatedData = insertApplicationSchema.parse(req.body);
      const application = await storage.createApplication(validatedData);
      res.status(201).json(application);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid data', details: error.errors });
      }
      console.error('Error creating application:', error);
      res.status(500).json({ error: 'Failed to create application' });
    }
  });

  // Service routes
  router.get('/api/services', async (req: Request, res: Response) => {
    try {
      const applicationId = req.query.applicationId as string;
      const services = await storage.getServices(applicationId);
      res.json(services);
    } catch (error) {
      console.error('Error fetching services:', error);
      res.status(500).json({ error: 'Failed to fetch services' });
    }
  });

  // Deployment routes
  router.get('/api/deployments', async (req: Request, res: Response) => {
    try {
      const clusterId = req.query.clusterId as string;
      const deployments = await storage.getDeployments(clusterId);
      res.json(deployments);
    } catch (error) {
      console.error('Error fetching deployments:', error);
      res.status(500).json({ error: 'Failed to fetch deployments' });
    }
  });

  router.post('/api/deployments', async (req: Request, res: Response) => {
    try {
      const validatedData = insertDeploymentSchema.parse(req.body);
      const deployment = await storage.createDeployment(validatedData);
      res.status(201).json(deployment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: 'Invalid data', details: error.errors });
      }
      console.error('Error creating deployment:', error);
      res.status(500).json({ error: 'Failed to create deployment' });
    }
  });

  return router;
}