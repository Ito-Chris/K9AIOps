import { 
  SelectTenant, InsertTenant,
  SelectCluster, InsertCluster,
  SelectApplication, InsertApplication,
  SelectService, InsertService,
  SelectDeployment, InsertDeployment
} from '../shared/schema.js';

export interface IStorage {
  // Tenant operations
  getTenants(): Promise<SelectTenant[]>;
  getTenant(id: string): Promise<SelectTenant | null>;
  createTenant(tenant: InsertTenant): Promise<SelectTenant>;
  updateTenant(id: string, tenant: Partial<InsertTenant>): Promise<SelectTenant | null>;
  deleteTenant(id: string): Promise<boolean>;

  // Cluster operations
  getClusters(tenantId?: string): Promise<SelectCluster[]>;
  getCluster(id: string): Promise<SelectCluster | null>;
  createCluster(cluster: InsertCluster): Promise<SelectCluster>;
  updateCluster(id: string, cluster: Partial<InsertCluster>): Promise<SelectCluster | null>;
  deleteCluster(id: string): Promise<boolean>;

  // Application operations
  getApplications(clusterId?: string): Promise<SelectApplication[]>;
  getApplication(id: string): Promise<SelectApplication | null>;
  createApplication(application: InsertApplication): Promise<SelectApplication>;
  updateApplication(id: string, application: Partial<InsertApplication>): Promise<SelectApplication | null>;
  deleteApplication(id: string): Promise<boolean>;

  // Service operations
  getServices(applicationId?: string): Promise<SelectService[]>;
  getService(id: string): Promise<SelectService | null>;
  createService(service: InsertService): Promise<SelectService>;
  updateService(id: string, service: Partial<InsertService>): Promise<SelectService | null>;
  deleteService(id: string): Promise<boolean>;

  // Deployment operations
  getDeployments(clusterId?: string): Promise<SelectDeployment[]>;
  getDeployment(id: string): Promise<SelectDeployment | null>;
  createDeployment(deployment: InsertDeployment): Promise<SelectDeployment>;
  updateDeployment(id: string, deployment: Partial<InsertDeployment>): Promise<SelectDeployment | null>;
}

export class MemStorage implements IStorage {
  private tenants: Map<string, SelectTenant> = new Map();
  private clusters: Map<string, SelectCluster> = new Map();
  private applications: Map<string, SelectApplication> = new Map();
  private services: Map<string, SelectService> = new Map();
  private deployments: Map<string, SelectDeployment> = new Map();

  constructor() {
    this.seedData();
  }

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }

  private seedData() {
    // Seed tenants
    const tenant1: SelectTenant = {
      id: 'tenant-1',
      name: 'Acme Corporation',
      email: 'admin@acme.com',
      plan: 'enterprise',
      status: 'active',
      createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      resourceQuota: { cpu: 16, memory: 64, storage: 1000, nodes: 10 }
    };

    const tenant2: SelectTenant = {
      id: 'tenant-2',
      name: 'TechStartup Inc',
      email: 'dev@techstartup.io',
      plan: 'professional',
      status: 'active',
      createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
      resourceQuota: { cpu: 8, memory: 32, storage: 500, nodes: 5 }
    };

    this.tenants.set(tenant1.id, tenant1);
    this.tenants.set(tenant2.id, tenant2);

    // Seed clusters
    const cluster1: SelectCluster = {
      id: 'cluster-1',
      tenantId: 'tenant-1',
      name: 'production-cluster',
      region: 'us-east-1',
      version: '1.28.2',
      status: 'running',
      nodeCount: 5,
      createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(),
      lastActivity: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      resources: { cpuUsage: 65, memoryUsage: 72, storageUsage: 45 }
    };

    const cluster2: SelectCluster = {
      id: 'cluster-2',
      tenantId: 'tenant-1',
      name: 'staging-cluster',
      region: 'us-west-2',
      version: '1.28.2',
      status: 'running',
      nodeCount: 3,
      createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
      lastActivity: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
      resources: { cpuUsage: 35, memoryUsage: 48, storageUsage: 25 }
    };

    const cluster3: SelectCluster = {
      id: 'cluster-3',
      tenantId: 'tenant-2',
      name: 'development-cluster',
      region: 'eu-west-1',
      version: '1.27.8',
      status: 'running',
      nodeCount: 2,
      createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      lastActivity: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
      resources: { cpuUsage: 28, memoryUsage: 41, storageUsage: 18 }
    };

    this.clusters.set(cluster1.id, cluster1);
    this.clusters.set(cluster2.id, cluster2);
    this.clusters.set(cluster3.id, cluster3);

    // Seed applications
    const app1: SelectApplication = {
      id: 'app-1',
      clusterId: 'cluster-1',
      name: 'web-frontend',
      namespace: 'production',
      image: 'nginx:1.21',
      replicas: 3,
      status: 'running',
      createdAt: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000).toISOString(),
      ports: [80, 443],
      environment: { NODE_ENV: 'production', API_URL: 'https://api.acme.com' }
    };

    const app2: SelectApplication = {
      id: 'app-2',
      clusterId: 'cluster-1',
      name: 'api-backend',
      namespace: 'production',
      image: 'node:18-alpine',
      replicas: 5,
      status: 'running',
      createdAt: new Date(Date.now() - 16 * 24 * 60 * 60 * 1000).toISOString(),
      ports: [3000],
      environment: { NODE_ENV: 'production', DB_HOST: 'postgres.internal' }
    };

    const app3: SelectApplication = {
      id: 'app-3',
      clusterId: 'cluster-3',
      name: 'test-app',
      namespace: 'default',
      image: 'python:3.9',
      replicas: 1,
      status: 'running',
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
      ports: [8000],
      environment: { DEBUG: 'true', ENV: 'development' }
    };

    this.applications.set(app1.id, app1);
    this.applications.set(app2.id, app2);
    this.applications.set(app3.id, app3);

    // Seed services
    const service1: SelectService = {
      id: 'service-1',
      applicationId: 'app-1',
      name: 'web-frontend-service',
      type: 'LoadBalancer',
      ports: [{ port: 80, targetPort: 80, protocol: 'TCP' }, { port: 443, targetPort: 443, protocol: 'TCP' }],
      externalIP: '54.123.45.67',
      status: 'active'
    };

    const service2: SelectService = {
      id: 'service-2',
      applicationId: 'app-2',
      name: 'api-backend-service',
      type: 'ClusterIP',
      ports: [{ port: 3000, targetPort: 3000, protocol: 'TCP' }],
      status: 'active'
    };

    this.services.set(service1.id, service1);
    this.services.set(service2.id, service2);

    // Seed deployments
    const deployment1: SelectDeployment = {
      id: 'deploy-1',
      clusterId: 'cluster-1',
      applicationId: 'app-1',
      version: 'v1.2.3',
      status: 'success',
      createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
      duration: 180,
      logs: ['Starting deployment...', 'Pulling image nginx:1.21', 'Rolling update completed successfully']
    };

    const deployment2: SelectDeployment = {
      id: 'deploy-2',
      clusterId: 'cluster-1',
      applicationId: 'app-2',
      version: 'v2.1.0',
      status: 'in-progress',
      createdAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
      logs: ['Starting deployment...', 'Pulling image node:18-alpine', 'Updating replicas...']
    };

    this.deployments.set(deployment1.id, deployment1);
    this.deployments.set(deployment2.id, deployment2);
  }

  // Tenant operations
  async getTenants(): Promise<SelectTenant[]> {
    return Array.from(this.tenants.values());
  }

  async getTenant(id: string): Promise<SelectTenant | null> {
    return this.tenants.get(id) || null;
  }

  async createTenant(tenant: InsertTenant): Promise<SelectTenant> {
    const newTenant: SelectTenant = {
      ...tenant,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
    };
    this.tenants.set(newTenant.id, newTenant);
    return newTenant;
  }

  async updateTenant(id: string, tenant: Partial<InsertTenant>): Promise<SelectTenant | null> {
    const existing = this.tenants.get(id);
    if (!existing) return null;
    
    const updated: SelectTenant = { ...existing, ...tenant };
    this.tenants.set(id, updated);
    return updated;
  }

  async deleteTenant(id: string): Promise<boolean> {
    return this.tenants.delete(id);
  }

  // Cluster operations
  async getClusters(tenantId?: string): Promise<SelectCluster[]> {
    const clusters = Array.from(this.clusters.values());
    return tenantId ? clusters.filter(c => c.tenantId === tenantId) : clusters;
  }

  async getCluster(id: string): Promise<SelectCluster | null> {
    return this.clusters.get(id) || null;
  }

  async createCluster(cluster: InsertCluster): Promise<SelectCluster> {
    const newCluster: SelectCluster = {
      ...cluster,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
      lastActivity: new Date().toISOString(),
    };
    this.clusters.set(newCluster.id, newCluster);
    return newCluster;
  }

  async updateCluster(id: string, cluster: Partial<InsertCluster>): Promise<SelectCluster | null> {
    const existing = this.clusters.get(id);
    if (!existing) return null;
    
    const updated: SelectCluster = { 
      ...existing, 
      ...cluster,
      lastActivity: new Date().toISOString()
    };
    this.clusters.set(id, updated);
    return updated;
  }

  async deleteCluster(id: string): Promise<boolean> {
    return this.clusters.delete(id);
  }

  // Application operations
  async getApplications(clusterId?: string): Promise<SelectApplication[]> {
    const applications = Array.from(this.applications.values());
    return clusterId ? applications.filter(a => a.clusterId === clusterId) : applications;
  }

  async getApplication(id: string): Promise<SelectApplication | null> {
    return this.applications.get(id) || null;
  }

  async createApplication(application: InsertApplication): Promise<SelectApplication> {
    const newApplication: SelectApplication = {
      ...application,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
    };
    this.applications.set(newApplication.id, newApplication);
    return newApplication;
  }

  async updateApplication(id: string, application: Partial<InsertApplication>): Promise<SelectApplication | null> {
    const existing = this.applications.get(id);
    if (!existing) return null;
    
    const updated: SelectApplication = { ...existing, ...application };
    this.applications.set(id, updated);
    return updated;
  }

  async deleteApplication(id: string): Promise<boolean> {
    return this.applications.delete(id);
  }

  // Service operations
  async getServices(applicationId?: string): Promise<SelectService[]> {
    const services = Array.from(this.services.values());
    return applicationId ? services.filter(s => s.applicationId === applicationId) : services;
  }

  async getService(id: string): Promise<SelectService | null> {
    return this.services.get(id) || null;
  }

  async createService(service: InsertService): Promise<SelectService> {
    const newService: SelectService = {
      ...service,
      id: this.generateId(),
    };
    this.services.set(newService.id, newService);
    return newService;
  }

  async updateService(id: string, service: Partial<InsertService>): Promise<SelectService | null> {
    const existing = this.services.get(id);
    if (!existing) return null;
    
    const updated: SelectService = { ...existing, ...service };
    this.services.set(id, updated);
    return updated;
  }

  async deleteService(id: string): Promise<boolean> {
    return this.services.delete(id);
  }

  // Deployment operations
  async getDeployments(clusterId?: string): Promise<SelectDeployment[]> {
    const deployments = Array.from(this.deployments.values());
    return clusterId ? deployments.filter(d => d.clusterId === clusterId) : deployments;
  }

  async getDeployment(id: string): Promise<SelectDeployment | null> {
    return this.deployments.get(id) || null;
  }

  async createDeployment(deployment: InsertDeployment): Promise<SelectDeployment> {
    const newDeployment: SelectDeployment = {
      ...deployment,
      id: this.generateId(),
      createdAt: new Date().toISOString(),
    };
    this.deployments.set(newDeployment.id, newDeployment);
    return newDeployment;
  }

  async updateDeployment(id: string, deployment: Partial<InsertDeployment>): Promise<SelectDeployment | null> {
    const existing = this.deployments.get(id);
    if (!existing) return null;
    
    const updated: SelectDeployment = { ...existing, ...deployment };
    this.deployments.set(id, updated);
    return updated;
  }
}