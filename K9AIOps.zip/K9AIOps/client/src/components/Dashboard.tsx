import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { SelectTenant, SelectCluster, SelectApplication, SelectDeployment } from '@shared/schema';
import { 
  Server, 
  Activity, 
  Database, 
  Zap, 
  Users, 
  Clock, 
  AlertCircle,
  CheckCircle,
  XCircle,
  Loader
} from 'lucide-react';

export function Dashboard() {
  const { data: tenants, isLoading: tenantsLoading } = useQuery<SelectTenant[]>({
    queryKey: ['/api/tenants'],
  });

  const { data: clusters, isLoading: clustersLoading } = useQuery<SelectCluster[]>({
    queryKey: ['/api/clusters'],
  });

  const { data: applications, isLoading: applicationsLoading } = useQuery<SelectApplication[]>({
    queryKey: ['/api/applications'],
  });

  const { data: deployments, isLoading: deploymentsLoading } = useQuery<SelectDeployment[]>({
    queryKey: ['/api/deployments'],
  });

  if (tenantsLoading || clustersLoading || applicationsLoading || deploymentsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const totalTenants = tenants?.length || 0;
  const totalClusters = clusters?.length || 0;
  const totalApplications = applications?.length || 0;
  const runningClusters = clusters?.filter(c => c.status === 'running').length || 0;
  const runningApplications = applications?.filter(a => a.status === 'running').length || 0;
  const recentDeployments = deployments?.slice(0, 5) || [];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'running':
      case 'active':
      case 'success':
        return <Badge variant="success" className="flex items-center gap-1">
          <CheckCircle className="h-3 w-3" />
          {status}
        </Badge>;
      case 'error':
      case 'failed':
        return <Badge variant="destructive" className="flex items-center gap-1">
          <XCircle className="h-3 w-3" />
          {status}
        </Badge>;
      case 'deploying':
      case 'in-progress':
        return <Badge variant="warning" className="flex items-center gap-1">
          <Loader className="h-3 w-3 animate-spin" />
          {status}
        </Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Kubernetes Dashboard
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Multi-tenant Kubernetes as a Service platform
          </p>
        </div>

        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Tenants</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalTenants}</div>
              <p className="text-xs text-muted-foreground">
                Active organizations
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Clusters</CardTitle>
              <Server className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{runningClusters}</div>
              <p className="text-xs text-muted-foreground">
                {runningClusters} of {totalClusters} running
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Running Apps</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{runningApplications}</div>
              <p className="text-xs text-muted-foreground">
                {runningApplications} of {totalApplications} running
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Deployments</CardTitle>
              <Zap className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{deployments?.length || 0}</div>
              <p className="text-xs text-muted-foreground">
                Total deployments
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Deployments */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Recent Deployments
              </CardTitle>
              <CardDescription>
                Latest deployment activities across all clusters
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentDeployments.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">
                    No recent deployments
                  </p>
                ) : (
                  recentDeployments.map((deployment) => (
                    <div key={deployment.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <div className="font-medium">{deployment.version}</div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(deployment.createdAt).toLocaleString()}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusBadge(deployment.status)}
                        {deployment.duration && (
                          <span className="text-xs text-muted-foreground">
                            {deployment.duration}s
                          </span>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Cluster Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Cluster Overview
              </CardTitle>
              <CardDescription>
                Status and resource usage of your clusters
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {clusters?.slice(0, 5).map((cluster) => (
                  <div key={cluster.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1">
                      <div className="font-medium">{cluster.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {cluster.region} • {cluster.nodeCount} nodes • v{cluster.version}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(cluster.status)}
                      <div className="text-xs text-muted-foreground">
                        CPU: {cluster.resources.cpuUsage}%
                      </div>
                    </div>
                  </div>
                )) || (
                  <p className="text-muted-foreground text-center py-4">
                    No clusters available
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Tenant Status */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Tenant Status
              </CardTitle>
              <CardDescription>
                Overview of tenant accounts and their plans
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {tenants?.map((tenant) => (
                  <div key={tenant.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1">
                      <div className="font-medium">{tenant.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {tenant.email}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(tenant.status)}
                      <Badge variant="outline">{tenant.plan}</Badge>
                    </div>
                  </div>
                )) || (
                  <p className="text-muted-foreground text-center py-4">
                    No tenants available
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* System Health */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5" />
                System Health
              </CardTitle>
              <CardDescription>
                Overall platform health and alerts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 border rounded-lg bg-green-50 dark:bg-green-900/20">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="font-medium">API Gateway</span>
                  </div>
                  <Badge variant="success">Healthy</Badge>
                </div>
                
                <div className="flex items-center justify-between p-3 border rounded-lg bg-green-50 dark:bg-green-900/20">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="font-medium">Database</span>
                  </div>
                  <Badge variant="success">Healthy</Badge>
                </div>
                
                <div className="flex items-center justify-between p-3 border rounded-lg bg-green-50 dark:bg-green-900/20">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="font-medium">Load Balancer</span>
                  </div>
                  <Badge variant="success">Healthy</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}