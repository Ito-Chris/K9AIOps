import { QueryClientProvider } from '@tanstack/react-query';
import { Router, Route, Switch } from 'wouter';
import { queryClient } from './lib/queryClient';
import { Dashboard } from './components/Dashboard';
import { ClustersPage } from './pages/ClustersPage';
import { ApplicationsPage } from './pages/ApplicationsPage';
import { TenantsPage } from './pages/TenantsPage';
import { Navigation } from './components/Navigation';
import './index.css';

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="pt-16">
          <Router>
            <Switch>
              <Route path="/" component={Dashboard} />
              <Route path="/clusters" component={ClustersPage} />
              <Route path="/applications" component={ApplicationsPage} />
              <Route path="/tenants" component={TenantsPage} />
              <Route>
                <div className="flex items-center justify-center min-h-screen">
                  <div className="text-center">
                    <h1 className="text-2xl font-bold mb-4">Page Not Found</h1>
                    <p className="text-muted-foreground">The requested page could not be found.</p>
                  </div>
                </div>
              </Route>
            </Switch>
          </Router>
        </main>
      </div>
    </QueryClientProvider>
  );
}

export default App;