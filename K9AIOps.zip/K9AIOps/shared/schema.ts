import { z } from 'zod';

// Core entities for K8s SaaS platform
export interface Tenant {
  id: string;
  name: string;
  email: string;
  plan: 'starter' | 'professional' | 'enterprise';
  status: 'active' | 'suspended' | 'pending';
  createdAt: string;
  resourceQuota: {
    cpu: number;
    memory: number;
    storage: number;
    nodes: number;
  };
}

export interface Cluster {
  id: string;
  tenantId: string;
  name: string;
  region: string;
  version: string;
  status: 'running' | 'stopped' | 'deploying' | 'error';
  nodeCount: number;
  createdAt: string;
  lastActivity: string;
  resources: {
    cpuUsage: number;
    memoryUsage: number;
    storageUsage: number;
  };
}

export interface Application {
  id: string;
  clusterId: string;
  name: string;
  namespace: string;
  image: string;
  replicas: number;
  status: 'running' | 'stopped' | 'deploying' | 'error';
  createdAt: string;
  ports: number[];
  environment: Record<string, string>;
}

export interface Service {
  id: string;
  applicationId: string;
  name: string;
  type: 'ClusterIP' | 'NodePort' | 'LoadBalancer';
  ports: Array<{
    port: number;
    targetPort: number;
    protocol: 'TCP' | 'UDP';
  }>;
  externalIP?: string;
  status: 'active' | 'pending' | 'failed';
}

export interface Deployment {
  id: string;
  clusterId: string;
  applicationId: string;
  version: string;
  status: 'success' | 'failed' | 'in-progress' | 'rolled-back';
  createdAt: string;
  duration?: number;
  logs: string[];
}

// Zod schemas for validation
export const tenantSchema = z.object({
  id: z.string(),
  name: z.string().min(1),
  email: z.string().email(),
  plan: z.enum(['starter', 'professional', 'enterprise']),
  status: z.enum(['active', 'suspended', 'pending']),
  createdAt: z.string(),
  resourceQuota: z.object({
    cpu: z.number().positive(),
    memory: z.number().positive(),
    storage: z.number().positive(),
    nodes: z.number().positive(),
  }),
});

export const clusterSchema = z.object({
  id: z.string(),
  tenantId: z.string(),
  name: z.string().min(1),
  region: z.string(),
  version: z.string(),
  status: z.enum(['running', 'stopped', 'deploying', 'error']),
  nodeCount: z.number().positive(),
  createdAt: z.string(),
  lastActivity: z.string(),
  resources: z.object({
    cpuUsage: z.number().min(0).max(100),
    memoryUsage: z.number().min(0).max(100),
    storageUsage: z.number().min(0).max(100),
  }),
});

export const applicationSchema = z.object({
  id: z.string(),
  clusterId: z.string(),
  name: z.string().min(1),
  namespace: z.string(),
  image: z.string(),
  replicas: z.number().positive(),
  status: z.enum(['running', 'stopped', 'deploying', 'error']),
  createdAt: z.string(),
  ports: z.array(z.number()),
  environment: z.record(z.string()),
});

export const serviceSchema = z.object({
  id: z.string(),
  applicationId: z.string(),
  name: z.string().min(1),
  type: z.enum(['ClusterIP', 'NodePort', 'LoadBalancer']),
  ports: z.array(z.object({
    port: z.number().positive(),
    targetPort: z.number().positive(),
    protocol: z.enum(['TCP', 'UDP']),
  })),
  externalIP: z.string().optional(),
  status: z.enum(['active', 'pending', 'failed']),
});

export const deploymentSchema = z.object({
  id: z.string(),
  clusterId: z.string(),
  applicationId: z.string(),
  version: z.string(),
  status: z.enum(['success', 'failed', 'in-progress', 'rolled-back']),
  createdAt: z.string(),
  duration: z.number().optional(),
  logs: z.array(z.string()),
});

// Insert schemas (omitting auto-generated fields)
export const insertTenantSchema = tenantSchema.omit({ id: true, createdAt: true });
export const insertClusterSchema = clusterSchema.omit({ id: true, createdAt: true, lastActivity: true });
export const insertApplicationSchema = applicationSchema.omit({ id: true, createdAt: true });
export const insertServiceSchema = serviceSchema.omit({ id: true });
export const insertDeploymentSchema = deploymentSchema.omit({ id: true, createdAt: true });

// Insert types
export type InsertTenant = z.infer<typeof insertTenantSchema>;
export type InsertCluster = z.infer<typeof insertClusterSchema>;
export type InsertApplication = z.infer<typeof insertApplicationSchema>;
export type InsertService = z.infer<typeof insertServiceSchema>;
export type InsertDeployment = z.infer<typeof insertDeploymentSchema>;

// Select types
export type SelectTenant = Tenant;
export type SelectCluster = Cluster;
export type SelectApplication = Application;
export type SelectService = Service;
export type SelectDeployment = Deployment;